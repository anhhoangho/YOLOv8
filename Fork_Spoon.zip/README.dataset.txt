# Fork vs Spoon V1 > 2023-10-31 12:22pm
https://universe.roboflow.com/tark-cucun/fork-vs-spoon-v1

Provided by a Roboflow user
License: CC BY 4.0

